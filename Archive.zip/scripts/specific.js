// refer to question 2 before development starts for scope document
// get URL query string
function getQueryStringValue (key) {
    return decodeURIComponent(window.location.search.replace(new RegExp("^(?:.*[&\\?]" + encodeURIComponent(key).replace(/[\.\+\*]/g, "\\$&") + "(?:\\=([^&]*))?)?.*$", "i"), "$1"));
}
// variable for the id
var id = getQueryStringValue("id");

if(id === undefined) {
    alert("There is no id");
}

var baseURL="https://api.magicthegathering.io/v1/cards";
var newURL=baseURL + "/" + id;

fetch(newURL)
 .then(function(response){
     return response.json();
 })
.then(function(json){
    specificCardInfo(json);
})

function specificCardInfo(json){
    var card=json.card
    
    var cardDetails=document.getElementById('cardDetails');

    cardDetails.innerHTML=
                        `<h2>${card.name}</h2>
                        <div><b>About:  </b> 
                        ${card.text}</div>
                        <div><b>Rarity: </b>Uncommon${card.rarity}</div>
                        <div><b>Color: </b>
                        ${card.colors}</div>`

    var cardSpecificImage=card.imageUrl

    var cardImage=document.getElementById('cardImage');
                    
    cardImage.innerHTML= `<img src= ${cardSpecificImage} width="100%" >`                    
 };






