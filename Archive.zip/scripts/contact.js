// refer to question 4 before development starts for scope document

document.getElementById('submitContact').addEventListener('click',function(){
  var firstNameInput= document.getElementById('firstName').value;
  var lastNameInput= document.getElementById('lastName').value;
  var emailInput= document.getElementById('email').value;
  var numberInput= document.getElementById('phone').value;

  var textPattern=/^[A-Za-z ]+$/;
  var numberPattern=/^\d+$/;
  var emailPattern=/^[A-Za-z0-9._-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$/;


  if (textPattern.test(firstNameInput)===false){
    alert("This field cannot be blank:  Name:");
  }

  if (textPattern.test(lastNameInput)===false){
    alert("This field cannot be blank:  Last Name:");
  }

  if (textPattern.test(numberInput)===false){
    alert("Please enter a correct phone number:  Telephone:");
  }

  if (textPattern.test(emailInput)===false){
    alert("Please enter a correct email address:  Email:");
  }

})