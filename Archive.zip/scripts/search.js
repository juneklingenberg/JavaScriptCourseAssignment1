
var searchButton = document.getElementById("searchButton");
var searchInput= document.getElementById('search');

searchButton.addEventListener("click", function(event) {

    event.preventDefault();

    var searchValue = searchInput.value;

    fetch("https://api.magicthegathering.io/v1/cards")
    .then(function(response){
        return response.json();
    })
    .then(function(jsonObject){
    
        loopThroughSearchResults(jsonObject, searchValue);
    })
    .catch(function(error){
        console.error(error);
    });

});




function loopThroughSearchResults(jsonObject, searchValue) {

	
	var cards = jsonObject.cards;

	var cardContainer = document.getElementById('cards');
  
    cardContainer.innerHTML = "";

    var filteredCards = cards.filter(function(card) {

        var cardName = card.name.toLowerCase();

        var value = searchValue.toLowerCase();

        if(cardName.startsWith(value)) {
        
            return true;
        }

    });


	filteredCards.forEach(function(card) {

		if(card.imageUrl === undefined){
			card.imageUrl = "https://via.placeholder.com/223x310";
		}
		  
		cardContainer.innerHTML += `<div class="col-sm-4">
										'<div class="card-container">
											<h4>${card.name}</h4>
											<img src="${card.imageUrl}" width="100%">
											<a href="card-specific.html?id=${card.id}" class="btn btn-success">View More</a>
										</div>
									</div>`;

	})
	
}
